<?php include 'inc/head.php'; ?>
  <title>FratNow</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="robots" content="noindex, nofollow">
  <meta name="googlebot" content="noindex, nofollow">

  <?php include 'inc/header.php'; ?>

  <main id="main">

    <!-- ======= Recent Blog Posts Section ======= -->
    <div class="banner-publications">
    <div class="container" >
      <div id="top-banner-section" class="row publications-row">
            <div class="col-xl-4 col-md-6 pd-50-top-bottom" id="banner-left-heading">
              <div>
                <h1>Pregnancy Awareness</h1>
               
              </div>
            </div>

      </div>
    </div>  
</div>
  <section id="about" class="about">
      <div class="container">
		<div class="row gy-4">
			<div class="col-xl-12 col-md-12 aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
      <div class="section-header text-center">
			

<p class="coming-soon"><b>Coming soon...more information on FRAT<sup>®</sup>, folate receptor autoantibodies and pregnancy! </b>
</p>
        </div>
			</div>
      </div>
    </div></section>
       
   
  </main><!-- End #main -->
  <?php include 'inc/footer.php'; ?>
  <?php include 'inc/footer-js.php'; ?>
  <?php include 'inc/footer-close.php'; ?>